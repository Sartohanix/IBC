

package ibcalpha.ibc;

public class IbcVersionInfo {
    public final static String IBC_VERSION = "3.20.0";
}
