// NB: this file is updated by the Ant build script

package ibcalpha.ibc;

public class IbcVersionInfo {
    public final static String IBC_VERSION = "3.20.0";
}
